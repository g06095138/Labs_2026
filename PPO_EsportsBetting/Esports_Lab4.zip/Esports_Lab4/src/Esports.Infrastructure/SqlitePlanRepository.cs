using Esports.Application;
using Esports.Domain;
using Microsoft.Data.Sqlite;

namespace Esports.Infrastructure;

public sealed class SqlitePlanRepository : IPlanRepository
{
    private readonly string connectionString;

    public SqlitePlanRepository(string path)
    {
        connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = Path.GetFullPath(path),
            ForeignKeys = true
        }.ToString();
        using var connection = Open();
        using var transaction = connection.BeginTransaction();
        using var command = connection.CreateCommand();
        command.Transaction = transaction;
        command.CommandText = """
            CREATE TABLE IF NOT EXISTS Plans (
                id TEXT NOT NULL PRIMARY KEY,
                name TEXT NOT NULL CHECK (length(trim(name)) > 0),
                initial_cash INTEGER NOT NULL CHECK (initial_cash BETWEEN 0 AND 100000000000)
            ) STRICT;
            CREATE TABLE IF NOT EXISTS Periods (
                plan_id TEXT NOT NULL REFERENCES Plans(id) ON DELETE CASCADE,
                number INTEGER NOT NULL CHECK (number BETWEEN 1 AND 3),
                q INTEGER NOT NULL CHECK (q BETWEEN 0 AND 100000000000),
                p INTEGER NOT NULL CHECK (p BETWEEN 100 AND 100000),
                v INTEGER NOT NULL CHECK (v BETWEEN 0 AND 100000000000),
                f INTEGER NOT NULL CHECK (f BETWEEN 0 AND 100000000000),
                a INTEGER NOT NULL CHECK (a BETWEEN 0 AND 100),
                settlement_percent INTEGER NOT NULL CHECK (settlement_percent BETWEEN 0 AND 100),
                PRIMARY KEY (plan_id, number)
            ) STRICT;
            """;
        command.ExecuteNonQuery();
        transaction.Commit();
    }

    public void Save(Plan plan)
    {
        Rules.Validate(plan);
        using var connection = Open();
        using var transaction = connection.BeginTransaction();
        using (var command = connection.CreateCommand())
        {
            command.Transaction = transaction;
            command.CommandText = """
                INSERT INTO Plans VALUES ($id, $name, $cash)
                ON CONFLICT(id) DO UPDATE SET name = excluded.name, initial_cash = excluded.initial_cash;
                DELETE FROM Periods WHERE plan_id = $id;
                """;
            command.Parameters.AddWithValue("$id", plan.Id.ToString("D"));
            command.Parameters.AddWithValue("$name", plan.Name);
            command.Parameters.AddWithValue("$cash", Scaled(plan.InitialCash));
            command.ExecuteNonQuery();
        }

        using var insert = connection.CreateCommand();
        insert.Transaction = transaction;
        insert.CommandText = "INSERT INTO Periods VALUES ($id, $number, $q, $p, $v, $f, $a, $settlement)";
        foreach (Period period in plan.Periods)
        {
            insert.Parameters.Clear();
            insert.Parameters.AddWithValue("$id", plan.Id.ToString("D"));
            insert.Parameters.AddWithValue("$number", period.Number);
            insert.Parameters.AddWithValue("$q", Scaled(period.Q));
            insert.Parameters.AddWithValue("$p", Scaled(period.P));
            insert.Parameters.AddWithValue("$v", Scaled(period.V));
            insert.Parameters.AddWithValue("$f", Scaled(period.F));
            insert.Parameters.AddWithValue("$a", period.A);
            insert.Parameters.AddWithValue("$settlement", period.SettlementPercent);
            insert.ExecuteNonQuery();
        }
        transaction.Commit();
    }

    public Plan? Get(Guid id)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT name, initial_cash, number, q, p, v, f, a, settlement_percent
            FROM Plans LEFT JOIN Periods ON Plans.id = Periods.plan_id
            WHERE Plans.id = $id ORDER BY number
            """;
        command.Parameters.AddWithValue("$id", id.ToString("D"));
        using var reader = command.ExecuteReader();
        if (!reader.Read())
            return null;

        string name = reader.GetString(0);
        decimal cash = reader.GetInt64(1) / 100m;
        var periods = new List<Period>(3);
        do
        {
            if (!reader.IsDBNull(2))
                periods.Add(new(reader.GetInt32(2), reader.GetInt64(3) / 100m, reader.GetInt64(4) / 100m,
                    reader.GetInt64(5) / 100m, reader.GetInt64(6) / 100m, reader.GetInt32(7), reader.GetInt32(8)));
        } while (reader.Read());

        var plan = new Plan(id, name, cash, periods.AsReadOnly());
        Rules.Validate(plan);
        return plan;
    }

    public IReadOnlyList<PlanSummary> List()
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT id, name FROM Plans ORDER BY name, id";
        using var reader = command.ExecuteReader();
        var plans = new List<PlanSummary>();
        while (reader.Read())
            plans.Add(new(Guid.Parse(reader.GetString(0)), reader.GetString(1)));
        return plans.AsReadOnly();
    }

    private SqliteConnection Open()
    {
        var connection = new SqliteConnection(connectionString);
        try
        {
            connection.Open();
            return connection;
        }
        catch
        {
            connection.Dispose();
            throw;
        }
    }

    private static long Scaled(decimal amount) => (long)(amount * 100);
}
