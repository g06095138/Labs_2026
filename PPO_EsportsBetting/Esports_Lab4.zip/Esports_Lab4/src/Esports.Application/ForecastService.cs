using Esports.Domain;

namespace Esports.Application;

public sealed record Summary(decimal Profit, decimal ClosingCash, decimal ClosingDebt, decimal Funding);
public sealed record Forecast(IReadOnlyList<PeriodResult> Periods, Summary Summary);

public sealed class ForecastService
{
    public Forecast Calculate(Plan plan)
    {
        Rules.Validate(plan);
        decimal cash = plan.InitialCash;
        decimal debt = 0m;
        var results = new List<PeriodResult>(3);
        foreach (Period period in plan.Periods.OrderBy(period => period.Number))
        {
            PeriodResult result = PeriodCalculator.Calculate(period, cash, debt);
            results.Add(result);
            cash = result.ClosingCash;
            debt = result.ClosingDebt;
        }
        var summary = new Summary(results.Sum(result => result.Profit), cash, debt,
            results.Max(result => Math.Max(0, -result.ClosingCash)));
        return new(results.AsReadOnly(), summary);
    }

    public (Summary First, Summary Second) Compare(Plan first, Plan second) =>
        (Calculate(first).Summary, Calculate(second).Summary);
}

public sealed record PlanSummary(Guid Id, string Name);

public interface IPlanRepository
{
    void Save(Plan plan);
    Plan? Get(Guid id);
    IReadOnlyList<PlanSummary> List();
}
