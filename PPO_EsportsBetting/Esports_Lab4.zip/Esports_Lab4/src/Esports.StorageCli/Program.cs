using System.Text.Json;
using Esports.Application;
using Esports.Domain;
using Esports.Infrastructure;
using Microsoft.Data.Sqlite;

try
{
    var options = new JsonSerializerOptions { WriteIndented = true, PropertyNameCaseInsensitive = true };
    object result;
    switch (args)
    {
        case ["save", var database, var path]:
            var plan = JsonSerializer.Deserialize<Plan>(File.ReadAllText(path), options)
                ?? throw new JsonException("Требуется объект плана.");
            Rules.Validate(plan);
            new SqlitePlanRepository(database).Save(plan);
            result = new PlanSummary(plan.Id, plan.Name);
            break;
        case ["list", var database]:
            result = new SqlitePlanRepository(database).List();
            break;
        case ["open", var database, var id]:
            var saved = new SqlitePlanRepository(database).Get(Guid.Parse(id))
                ?? throw new ArgumentException("План с указанным ID не найден.", "Id");
            result = new { Plan = saved, Forecast = new ForecastService().Calculate(saved) };
            break;
        default:
            throw new ArgumentException("Команды: save <db> <plan.json> | list <db> | open <db> <id>");
    }
    Console.WriteLine(JsonSerializer.Serialize(result, options));
    return 0;
}
catch (Exception error) when (error is ArgumentException or FormatException or IOException or JsonException
    or SqliteException or UnauthorizedAccessException)
{
    Console.Error.WriteLine(error.Message);
    return 2;
}
