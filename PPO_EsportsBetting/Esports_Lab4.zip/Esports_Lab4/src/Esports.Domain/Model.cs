namespace Esports.Domain;

public sealed record Period(int Number, decimal Q, decimal P, decimal V, decimal F,
    int A, int SettlementPercent = 100);

public sealed record Plan(Guid Id, string Name, decimal InitialCash, IReadOnlyList<Period> Periods);

public sealed record PeriodResult(int Number, decimal Stakes, decimal OpeningCash, decimal OpeningDebt,
    decimal AccruedPayout, decimal PaidPayout, decimal Ggr, decimal Margin, decimal Expenses,
    decimal Profit, decimal ClosingCash, decimal ClosingDebt);

public static class Rules
{
    public const decimal MaxMoney = 1_000_000_000m;
    public const decimal MaxOdds = 1000m;

    public static void Validate(Plan plan)
    {
        Require(plan.Id != Guid.Empty, "Id", "требуется идентификатор");
        Require(!string.IsNullOrWhiteSpace(plan.Name), "Name", "укажите название плана");
        Money(plan.InitialCash, "InitialCash");
        Require(plan.Periods is { Count: 3 } && plan.Periods.All(p => p is not null) &&
            plan.Periods.Select(p => p.Number).OrderBy(number => number).SequenceEqual(new[] { 1, 2, 3 }),
            "Periods", "требуются три периода с уникальными номерами 1–3");
        foreach (Period period in plan.Periods!)
        {
            string field = $"Periods[{period.Number}]";
            Money(period.Q, $"{field}.Q");
            Money(period.V, $"{field}.V");
            Money(period.F, $"{field}.F");
            Require(period.P is >= 1 and <= MaxOdds && Round(period.P) == period.P,
                $"{field}.P", "допустим коэффициент от 1 до 1000 с точностью до сотых");
            Require(period.A is >= 0 and <= 100, $"{field}.A", "допустимы проценты от 0 до 100");
            Require(period.SettlementPercent is >= 0 and <= 100, $"{field}.SettlementPercent",
                "допустимы проценты от 0 до 100");
        }
    }

    private static void Money(decimal value, string field) =>
        Require(value is >= 0 and <= MaxMoney && Round(value) == value,
            field, "допустима сумма от 0 до 1 000 000 000 с точностью до копеек");

    private static void Require(bool condition, string field, string reason)
    {
        if (!condition)
            throw new ArgumentException(reason, field);
    }

    public static decimal Round(decimal value) => decimal.Round(value, 2, MidpointRounding.AwayFromZero);
}

public static class PeriodCalculator
{
    public static PeriodResult Calculate(Period period, decimal openingCash, decimal openingDebt)
    {
        decimal accrued = Rules.Round(period.Q * period.A / 100 * period.P);
        decimal currentPaid = Rules.Round(accrued * period.SettlementPercent / 100);
        decimal paid = openingDebt + currentPaid;
        decimal ggr = period.Q - accrued;
        decimal expenses = period.V + period.F;
        return new(period.Number, period.Q, openingCash, openingDebt, accrued, paid, ggr,
            ggr - period.V, expenses, ggr - expenses, openingCash + period.Q - paid - expenses,
            accrued - currentPaid);
    }
}
