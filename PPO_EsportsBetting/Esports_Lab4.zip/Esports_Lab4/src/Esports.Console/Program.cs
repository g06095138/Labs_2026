using System.Text.Json;
using Esports.Application;
using Esports.Domain;

try
{
    var forecasts = new ForecastService();
    object result = args switch
    {
        ["forecast", var path] => forecasts.Calculate(Load(path)),
        ["compare", var first, var second] => Compare(forecasts, first, second),
        _ => throw new ArgumentException("Команды: forecast <plan.json> | compare <first.json> <second.json>")
    };
    Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
    return 0;
}
catch (Exception error) when (error is ArgumentException or IOException or JsonException or UnauthorizedAccessException)
{
    Console.Error.WriteLine(error.Message);
    return 2;
}

static Plan Load(string path) =>
    JsonSerializer.Deserialize<Plan>(File.ReadAllText(path), new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
    ?? throw new JsonException("Требуется объект плана.");

static object Compare(ForecastService forecasts, string first, string second)
{
    var pair = forecasts.Compare(Load(first), Load(second));
    return new { pair.First, pair.Second };
}
