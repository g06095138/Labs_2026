using Esports.Application;
using Esports.Domain;
using Esports.Infrastructure;
using Microsoft.Data.Sqlite;
using Xunit;

namespace Esports.StorageTests;

public sealed class StorageTests : IDisposable
{
    private readonly string directory = Directory.CreateTempSubdirectory("esports-").FullName;
    private string PathToDatabase => Path.Combine(directory, "plans.db");
    private SqlitePlanRepository Open() => new(PathToDatabase);

    private static Plan Sample() => new(Guid.NewGuid(), "Контрольная линия", 100_000.01m, new Period[]
    {
        new(1, 200_000.11m, 1.85m, 10_000.12m, 40_000.13m, 50, 75),
        new(2, 190_000.21m, 2.01m, 10_000.22m, 40_000.23m, 60),
        new(3, 180_000.31m, 1.93m, 10_000.32m, 40_000.33m, 70, 80)
    });

    private static void AssertPlan(Plan expected, Plan actual)
    {
        Assert.Equal(expected.Id, actual.Id);
        Assert.Equal(expected.Name, actual.Name);
        Assert.Equal(expected.InitialCash, actual.InitialCash);
        Assert.Equal(expected.Periods.ToArray(), actual.Periods.ToArray());
    }

    [Fact]
    public void ReopenPreservesInputsAndForecast()
    {
        Plan plan = Sample();
        Open().Save(plan);
        Plan restored = Assert.IsType<Plan>(Open().Get(plan.Id));
        AssertPlan(plan, restored);
        var service = new ForecastService();
        Forecast first = service.Calculate(plan);
        Forecast second = service.Calculate(restored);
        Assert.Equal(first.Summary, second.Summary);
        Assert.Equal(first.Periods.ToArray(), second.Periods.ToArray());
    }

    [Fact]
    public void UpdatePreservesCountAndOtherPlan()
    {
        Plan original = Sample();
        Plan other = Sample();
        var store = Open();
        store.Save(original);
        store.Save(other);
        Plan updated = original with
        {
            Name = "Обновлённый план",
            InitialCash = 0.03m,
            Periods = original.Periods.Select(p => new Period(p.Number, p.Q + 0.09m,
                2.19m, 10.01m, 20.02m, 98, 95)).ToArray()
        };
        store.Save(updated);
        Assert.Equal(2, store.List().Count);
        Assert.Contains(new PlanSummary(updated.Id, updated.Name), store.List());
        AssertPlan(updated, Assert.IsType<Plan>(Open().Get(updated.Id)));
        AssertPlan(other, Assert.IsType<Plan>(Open().Get(other.Id)));
    }

    [Fact]
    public void InvalidPlanLeavesExistingData()
    {
        Plan original = Sample();
        var store = Open();
        store.Save(original);
        Assert.Throws<ArgumentException>(() => store.Save(original with { InitialCash = -1 }));
        Assert.Single(store.List());
        AssertPlan(original, Assert.IsType<Plan>(store.Get(original.Id)));
    }

    [Fact]
    public void FailedInsertRollsBackWholeUpdate()
    {
        Plan original = Sample();
        var store = Open();
        store.Save(original);
        using (var connection = new SqliteConnection($"Data Source={PathToDatabase}"))
        {
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = """
                CREATE TRIGGER reject_second BEFORE INSERT ON Periods WHEN NEW.number = 2
                BEGIN SELECT RAISE(ABORT, 'test rollback'); END;
                """;
            command.ExecuteNonQuery();
        }
        Assert.Throws<SqliteException>(() => store.Save(original with { Name = "Не должно сохраниться" }));
        AssertPlan(original, Assert.IsType<Plan>(Open().Get(original.Id)));
    }

    public void Dispose()
    {
        SqliteConnection.ClearAllPools();
        Directory.Delete(directory, recursive: true);
    }
}
