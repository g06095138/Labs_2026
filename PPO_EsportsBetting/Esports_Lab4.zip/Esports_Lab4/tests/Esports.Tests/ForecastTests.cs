using Esports.Application;
using Esports.Domain;
using Xunit;

namespace Esports.Tests;

public sealed class ForecastTests
{
    private readonly ForecastService service = new();

    private static Plan Create(int percentage = 50, decimal q = 200_000, decimal v = 10_000,
        decimal cash = 100_000) => new(Guid.NewGuid(), "Линия", cash,
        Enumerable.Range(1, 3).Select(i => new Period(i, q, 1.85m, v, 40_000, percentage)).ToArray());

    [Theory]
    [InlineData(0, 250000, 400000, 550000, 450000, 0)]
    [InlineData(50, 65000, 30000, -5000, -105000, 5000)]
    [InlineData(100, -120000, -340000, -560000, -660000, 560000)]
    public void StandardLine(int a, int first, int second, int third, int profit, int funding)
    {
        Forecast report = service.Calculate(Create(a));
        Assert.Equal(new decimal[] { first, second, third }, report.Periods.Select(p => p.ClosingCash));
        decimal payout = a switch { 0 => 0, 50 => 185_000, _ => 370_000 };
        Assert.All(report.Periods, p =>
        {
            Assert.Equal(payout, p.AccruedPayout);
            Assert.Equal(payout, p.PaidPayout);
            Assert.Equal(200_000 - payout, p.Ggr);
            Assert.Equal(190_000 - payout, p.Margin);
            Assert.Equal(50_000, p.Expenses);
            Assert.Equal(150_000 - payout, p.Profit);
        });
        Assert.Equal(new Summary(profit, third, 0, funding), report.Summary);
    }

    [Fact]
    public void ZeroActivityAndZeroClosingCash()
    {
        Assert.Equal(new Summary(-120_000, -20_000, 0, 20_000), service.Calculate(Create(q: 0, v: 0)).Summary);
        Assert.Equal(new Summary(-105_000, 0, 0, 0), service.Calculate(Create(cash: 105_000)).Summary);
        Assert.Equal(0, service.Calculate(Create(cash: 0)).Periods[0].OpeningCash);
    }

    [Fact]
    public void DifferentPeriodsCarryDebtAndCash()
    {
        Plan plan = new(Guid.NewGuid(), "Перенос", 0, new Period[]
        {
            new(3, 100, 1.50m, 5, 10, 50, 0),
            new(1, 100, 2, 10, 40, 100, 25),
            new(2, 200, 2, 0, 30, 25)
        });
        Forecast result = service.Calculate(plan);
        Assert.Equal(new decimal[] { 0, -80, 5 }, result.Periods.Select(p => p.ClosingCash));
        Assert.Equal(new decimal[] { 150, 0, 75 }, result.Periods.Select(p => p.ClosingDebt));
        Assert.Equal(150, result.Periods[1].OpeningDebt);
        Assert.Equal(250, result.Periods[1].PaidPayout);
        Assert.Equal(new Summary(-70, 5, 75, 80), result.Summary);
    }

    [Fact]
    public void CompareAndRepeatLeaveInputsIntact()
    {
        Plan first = Create();
        Plan second = Create(100);
        Period[] snapshot = first.Periods.ToArray();
        var pair = service.Compare(first, second);
        Assert.Equal(-105_000, pair.First.Profit);
        Assert.Equal(-660_000, pair.Second.Profit);
        Assert.Equal(pair.First, service.Calculate(first).Summary);
        Assert.Equal(snapshot, first.Periods);
    }

    [Fact]
    public void RejectsInvalidFields()
    {
        Plan plan = Create();
        Assert.Equal("InitialCash", Assert.Throws<ArgumentException>(() =>
            service.Calculate(plan with { InitialCash = -0.01m })).ParamName);
        Assert.Equal("Name", Assert.Throws<ArgumentException>(() =>
            service.Calculate(plan with { Name = " " })).ParamName);
        Assert.Equal("Periods", Assert.Throws<ArgumentException>(() =>
            service.Calculate(plan with { Periods = new[] { plan.Periods[0], plan.Periods[0], plan.Periods[2] } })).ParamName);
        Assert.Equal("Periods", Assert.Throws<ArgumentException>(() =>
            service.Calculate(plan with { Periods = plan.Periods.Take(2).ToArray() })).ParamName);
        Assert.Equal("Periods[1].A", Assert.Throws<ArgumentException>(() =>
            service.Calculate(Create(101))).ParamName);
    }

    [Fact]
    public void RoundsHalfKopeck()
    {
        var result = PeriodCalculator.Calculate(new Period(1, 0.01m, 1, 0, 0, 50), 0, 0);
        Assert.Equal(0.01m, result.AccruedPayout);
    }
}
