# ЛР4. Хранение финансовых планов eSports Betting в SQLite

Учебный консольный проект на C# и .NET 10. SQLite создаёт схему при первом запуске.
[Модель данных](docs/data.md), [ER-диаграмма Чена](docs/diagrams/er.pdf) и
[отчёт Word](ЛР4_eSports_Betting.docx) входят в комплект.

## Сборка в VS Code

Установите .NET SDK 10.0.403. Откройте в VS Code распакованную папку Esports_Lab4,
где лежит Esports.sln. В меню выберите «Терминал → Создать терминал» и выполните команды.

```sh
dotnet restore Esports.sln --locked-mode
dotnet build Esports.sln -c Release --no-restore
dotnet test Esports.sln -c Release --no-build
```

## Демонстрация хранения

Используйте новое имя файла базы, если plans.db уже существует.
Сохраните два плана, выведите список и откройте первый по ID в отдельном запуске.

```sh
dotnet run --project src/Esports.StorageCli -c Release --no-build -- save plans.db examples/standard.json
dotnet run --project src/Esports.StorageCli -c Release --no-build -- save plans.db examples/aggressive.json
dotnet run --project src/Esports.StorageCli -c Release --no-build -- list plans.db
dotnet run --project src/Esports.StorageCli -c Release --no-build -- open plans.db 00000000-0000-4000-8000-000000000001
```

Сохраните подготовленный файл с тем же ID и проверьте результат.

```sh
dotnet run --project src/Esports.StorageCli -c Release --no-build -- save plans.db examples/standard-updated.json
dotnet run --project src/Esports.StorageCli -c Release --no-build -- list plans.db
dotnet run --project src/Esports.StorageCli -c Release --no-build -- open plans.db 00000000-0000-4000-8000-000000000001
```

В списке останутся два плана. Первый сохранит ID и получит новое название и стартовую
сумму 105 000,01 ₽. Прогноз после чтения пересчитается, конечный остаток составит 0 ₽.
Второй план останется прежним. Формулы описаны в [проектировании](docs/design.md).
