# eSports Betting. Лабораторная работа 3

Учебный аналитический модуль прогнозирует три периода и сравнивает две стратегии.
Используется C# и .NET 10. Для разработки откройте в VS Code папку с Esports.sln.
Установите .NET SDK 10.0.403 или совместимый SDK .NET 10 согласно global.json.

```sh
dotnet restore Esports.sln --locked-mode
dotnet build Esports.sln -c Release --no-restore
dotnet test Esports.sln -c Release --no-build
dotnet run --project src/Esports.Console -c Release --no-build -- forecast examples/standard.json
dotnet run --project src/Esports.Console -c Release --no-build -- compare examples/standard.json examples/aggressive.json
```

В контрольном плане GGR составляет 15 000 ₽ и прибыль −35 000 ₽ за период.
Остатки денег составляют 65 000 ₽, 30 000 ₽ и −5 000 ₽.
Метод расчёта и отличие от Python-скрипта первой работы описаны в [проектировании](docs/design.md).
