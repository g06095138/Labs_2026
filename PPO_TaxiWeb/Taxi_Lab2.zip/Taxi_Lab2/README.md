# ЛР2. Архитектура и модель данных службы такси

[Отчёт Word](docs/reports/ЛР2_Служба_такси.docx). Работа использует предметную область курсовой «Служба такси». Соответствие пунктам методички описано в [docs/adaptation.md](docs/adaptation.md).

Начните с docs/design.md и docs/data.md. [ER-диаграмма в нотации Чена](docs/diagrams/er-chen.pdf) также включена в отчёт Word. Диаграммы компонентов, классов, данных и жизненного цикла находятся в docs/diagrams. Пройдите сценарий: клиент создаёт заказ → диспетчер назначает свободного водителя → водитель начинает и завершает поездку.

Архив содержит исходники общего решения Taxi.sln, чтобы его можно было собрать и запустить отдельно. Протокол текущего прогона расположен в [docs/test-results/taxi-tests.trx](docs/test-results/taxi-tests.trx).

## Сборка и проверка

Выполните из каталога с Taxi.sln. Требуется .NET SDK 10.0.403 и доступ к NuGet для первоначального восстановления.

```sh
dotnet restore Taxi.sln --locked-mode
dotnet build Taxi.sln -c Release --no-restore
dotnet test Taxi.sln -c Release --no-build
dotnet run --project src/Taxi.Console -c Release --no-build
```

Для ручной проверки сценария запустите сайт локально. SQLite создаётся автоматически. Учебный пароль для client, dispatcher и driver1 — `TaxiDemo!2026`.

```sh
dotnet run --project src/Taxi.Web -c Release --no-build --no-launch-profile -- --urls http://127.0.0.1:5080
```
