using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Data.Sqlite;
using Taxi.Domain;
using Taxi.Infrastructure;

var options = new JsonSerializerOptions
{
    WriteIndented = true,
    PropertyNameCaseInsensitive = true,
    Converters = { new JsonStringEnumConverter() }
};

try
{
    object result = args switch
    {
        ["create", var db, var file] => Open(db).Create("client-1", ReadTrip(file)),
        ["list", var db] => Open(db).Orders(),
        ["open", var db, var id] => Open(db).Get(id) ?? throw new RuleException("Order", "Заказ не найден."),
        ["update", var db, var id, var file] => Open(db).Update("client-1", id, ReadTrip(file)),
        _ => throw new ArgumentException(
            "Команды: create <db> <json>, list <db>, open <db> <id>, update <db> <id> <json>.")
    };
    Console.WriteLine(JsonSerializer.Serialize(result, options));
    return 0;
}
catch (RuleException error)
{
    Console.Error.WriteLine($"{error.Field}: {error.Message}");
    return 2;
}
catch (Exception error) when (error is IOException or UnauthorizedAccessException
    or ArgumentException or JsonException or SqliteException)
{
    Console.Error.WriteLine(error.Message);
    return 2;
}

static SqliteStore Open(string path)
{
    var store = new SqliteStore(path);
    store.Initialize();
    return store;
}

TripInput ReadTrip(string path) =>
    JsonSerializer.Deserialize<TripInput>(File.ReadAllText(path), options)
    ?? throw new JsonException("Требуется объект с параметрами поездки.");
