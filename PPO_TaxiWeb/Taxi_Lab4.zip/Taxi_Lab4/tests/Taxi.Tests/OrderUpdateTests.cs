using Taxi.Domain;
using Taxi.Infrastructure;
using Xunit;

namespace Taxi.Tests;

public sealed class OrderUpdateTests : IDisposable
{
    private readonly string directory = Directory.CreateTempSubdirectory("taxi-update-").FullName;
    private readonly TripInput original = new("Учебный клиент", "+70000000000", "Вокзал", "Университет", 4.01m, "comfort");

    [Fact]
    public void UpdatePreservesIdAndOtherOrderAndRecalculatesCost()
    {
        var store = Open();
        Order first = store.Create("client-1", original);
        Order second = store.Create("client-2", original);
        var revised = original with { Pickup = "Аэропорт", Destination = "Гостиница", DistanceKm = 5.01m, TariffId = "business" };
        Order updated = store.Update("client-1", first.Id, revised);

        var reopened = Open();
        Assert.Equal(first.Id, updated.Id);
        Assert.Equal(first.CreatedAt, updated.CreatedAt);
        Assert.Equal(revised.Pickup, updated.Pickup);
        Assert.Equal(revised.Destination, updated.Destination);
        Assert.Equal(revised.DistanceKm, updated.DistanceKm);
        Assert.Equal(revised.TariffId, updated.TariffId);
        Assert.Equal(500.50m, updated.Cost);
        Assert.Equal(updated, reopened.Get(first.Id));
        Assert.Equal(second, reopened.Get(second.Id));
        Assert.Equal(2, reopened.Orders().Count);
        var tariff = new Tariff(updated.TariffId, "Бизнес", updated.BasePrice, updated.Rate);
        Assert.Equal(updated.Cost, new QuoteService().Calculate(tariff, updated.DistanceKm).Total);
    }

    [Fact]
    public void InvalidUpdateLeavesOriginalUnchanged()
    {
        var store = Open();
        Order first = store.Create("client-1", original);
        Assert.Equal("DistanceKm", Assert.Throws<RuleException>(() =>
            store.Update("client-1", first.Id, original with { DistanceKm = 0 })).Field);
        Assert.Equal("Order", Assert.Throws<RuleException>(() => store.Update("client-2", first.Id, original)).Field);
        Assert.Equal(first, Assert.Single(Open().Orders()));
    }

    [Fact]
    public void AssignedOrderCannotBeUpdated()
    {
        var store = Open();
        Order order = store.Create("client-1", original);
        store.Assign(order.Id, "driver-1");
        Assert.Equal("Status", Assert.Throws<RuleException>(() =>
            store.Update("client-1", order.Id, original with { Pickup = "Аэропорт" })).Field);
        var saved = Assert.IsType<Order>(Open().Get(order.Id));
        Assert.Equal(OrderStatus.Assigned, saved.Status);
        Assert.Equal(order.Pickup, saved.Pickup);
    }

    private SqliteStore Open()
    {
        var store = new SqliteStore(Path.Combine(directory, "taxi.db"));
        store.Initialize();
        return store;
    }

    public void Dispose()
    {
        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
        Directory.Delete(directory, recursive: true);
    }
}
