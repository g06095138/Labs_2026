# ЛР4. Хранение заказов службы такси

Цель работы — сохранять заказы в SQLite, читать их после повторного открытия базы и менять состояние существующего заказа по его ID. Стоимость хранится целым числом копеек. Назначение водителя и смена состояния выполняются в транзакциях.

- [Отчёт Word](docs/reports/ЛР4_Служба_такси.docx)
- [Описание модели данных](docs/data.md) и [ER-диаграмма](docs/diagrams/er.pdf)
- [Реализация SQLite](src/Taxi.Infrastructure/SqliteStore.cs)
- [Интеграционные тесты](tests/Taxi.Tests/TaxiTests.cs) и [протокол ЛР4](docs/test-results/lab4-tests.trx)

## Сборка и проверка

Выполнить из корня комплекта с .NET SDK 10.0.403. Для первого восстановления зависимостей нужен доступ к NuGet.

```sh
dotnet restore Taxi.sln --locked-mode
dotnet build Taxi.sln -c Release --no-restore
dotnet test Taxi.sln -c Release --no-build
dotnet test Taxi.sln -c Release --no-build --filter 'FullyQualifiedName~Storage_|FullyQualifiedName~Assignment_|FullyQualifiedName~Workflow_'
```

В проверенной сборке прошли 29 тестов, включая 7 проверок ЛР4. Тесты создают собственные временные базы SQLite.

## Демонстрация

1. Запустить сайт командой ниже. Файл базы создаётся при первом запуске в каталоге App_Data веб-проекта.
2. Войти как `client` с учебным паролем `TaxiDemo!2026`. Создать заказ по тарифу «Комфорт» на 4 км. Ожидаемая стоимость — 270 ₽.
3. Войти как `dispatcher` с тем же учебным паролем и назначить заказ водителю. Войти как назначенный водитель (`driver1`, `driver2` или `driver3`), начать и завершить поездку.
4. Остановить и запустить сайт с той же базой. Войти как `client` и убедиться, что заказ сохранился со статусом «Завершён» и стоимостью 270 ₽.

```sh
dotnet run --project src/Taxi.Web -c Release --no-build --no-launch-profile -- --urls http://127.0.0.1:5080
```
