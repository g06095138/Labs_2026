# ЛР4. Хранение заказов службы такси

Комплект включает SQLite-хранилище, консольные команды, интеграционные тесты,
[отчёт Word](docs/reports/ЛР4_Служба_такси.docx) и [ER-диаграмму](docs/diagrams/er.pdf).

## Сборка в VS Code

Установите .NET SDK 10.0.403 и откройте папку Taxi_Lab4, в которой лежит Taxi.sln.
Откройте **Терминал → Создать терминал** и выполните следующие команды.

```sh
dotnet restore Taxi.sln --locked-mode
dotnet build Taxi.sln -c Release --no-restore
dotnet test Taxi.sln -c Release --no-build
```

## Демонстрация SQLite

Создайте заказ. Файл taxi-lab4.db появится рядом с Taxi.sln.

```sh
dotnet run --project src/Taxi.Console -c Release --no-build -- create taxi-lab4.db examples/order.json
```

В выводе будет Id и стоимость 270,30 ₽. Скопируйте значение Id и подставьте его вместо ID_ЗАКАЗА.
Команда create завершается, поэтому последующие команды открывают базу в новом процессе.

```sh
dotnet run --project src/Taxi.Console -c Release --no-build -- list taxi-lab4.db
dotnet run --project src/Taxi.Console -c Release --no-build -- open taxi-lab4.db ID_ЗАКАЗА
dotnet run --project src/Taxi.Console -c Release --no-build -- update taxi-lab4.db ID_ЗАКАЗА examples/order-updated.json
dotnet run --project src/Taxi.Console -c Release --no-build -- list taxi-lab4.db
```

После обновления у заказа останется тот же ID, стоимость станет 500,50 ₽.
Число заказов до и после update совпадёт. Каждый вызов create добавляет отдельный заказ.
